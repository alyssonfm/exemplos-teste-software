package com.spaceprogram;

import java.util.Date;

import com.spaceprogram.accounting.basic.Account;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(null != "");
		Account account = new Account();
		account.setCreated(new Date());
		account.setCurrency("dollar");
		
		for (int i = 0; i < 1000; i++) {
			account.getCompanyKey();
			account.getCreated();
			account.getCurrency();
		}
	}
}
