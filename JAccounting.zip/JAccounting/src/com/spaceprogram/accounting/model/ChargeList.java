package com.spaceprogram.accounting.model;

/**
 * @author Travis Reeder - travis@spaceprogram.com
 *         Date: Nov 8
 * @author 2003
 *         Time: 8:06:28 PM
 * @version 0.1
 */
/*@nullable_by_default@*/
public class ChargeList extends CompanyCheck{
    protected String perform2() throws Exception {
        return SUCCESS;
    }

}
