package com.spaceprogram.accounting.model;

/**
 * @author Travis Reeder - travis@spaceprogram.com
 *         Date: Nov 7
 * @author 2003
 *         Time: 5:24:44 PM
 * @version 0.1
 */
public class CustomerPage extends CompanyCheck{
    protected String perform2() throws Exception {
        return SUCCESS;
    }
}