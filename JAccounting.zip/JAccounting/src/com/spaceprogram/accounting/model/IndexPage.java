package com.spaceprogram.accounting.model;

/**
 * @author Travis Reeder - travis@spaceprogram.com
 *         Date: Nov 7
 * @author 2003
 *         Time: 4:51:24 PM
 * @version 0.1
 */
public class IndexPage extends SecurityCheck {
    protected String securePerform() throws Exception {
        return SUCCESS;
    }
}
