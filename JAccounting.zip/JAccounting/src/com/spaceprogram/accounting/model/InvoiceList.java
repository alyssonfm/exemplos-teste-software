package com.spaceprogram.accounting.model;

/**
 * @author Travis Reeder - travis@spaceprogram.com
 *         Date: Nov 8
 * @author 2003
 *         Time: 8:07:10 PM
 * @version 0.1
 */
public class InvoiceList extends CompanyCheck{
    protected String perform2() throws Exception {
        return SUCCESS;
    }

}
