package com.spaceprogram.accounting.model;

/**
 * @author Travis Reeder - travis@spaceprogram.com
 *         Date: 1-Apr-2004
 *         Time: 7:34:53 PM
 * @version 0.1
 */
public class Vendor extends CompanyCheck{
	
    protected String perform2() throws Exception {
        return "success";
    }

}
