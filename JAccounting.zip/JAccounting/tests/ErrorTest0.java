import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test1");
        com.spaceprogram.accounting.basic.ChargeLine chargeLine0 = new com.spaceprogram.accounting.basic.ChargeLine();
        // during test generation this statement threw an exception of type java.lang.NullPointerException in error
        java.util.Date date1 = chargeLine0.getTransactionDate();
    }
}

