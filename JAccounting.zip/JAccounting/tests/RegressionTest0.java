import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.io.InputStream inputStream0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.ByteArrayDataSource byteArrayDataSource2 = new com.spaceprogram.mail.ByteArrayDataSource(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Stream closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.spaceprogram.usersystem.UserManager userManager0 = com.spaceprogram.accounting.model.Base.getUserManager();
        org.junit.Assert.assertNull(userManager0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.spaceprogram.util.FormUtils formUtils0 = new com.spaceprogram.util.FormUtils();
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String str0 = org.infohazard.maverick.ctl.Throwaway2.ERROR;
        org.junit.Assert.assertEquals("'" + str0 + "' != '" + "error" + "'", str0, "error");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str0 = com.spaceprogram.util.Mailer.CTYPE_PLAIN_TEXT;
        org.junit.Assert.assertEquals("'" + str0 + "' != '" + "text/plain" + "'", str0, "text/plain");
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str4 = com.spaceprogram.util.StringUtils.padString("text/plain", (int) (byte) -1, '#', '#');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "text/plain" + "'", str4, "text/plain");
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.String str1 = com.spaceprogram.util.ServletUtils.headWithTitle("hi!");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n" + "'", str1, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n");
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.html.forms.AccountSelect accountSelect2 = new com.spaceprogram.accounting.html.forms.AccountSelect(session0, (java.lang.Integer) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.String str2 = com.spaceprogram.util.FormUtils.createHourSelect((int) (byte) 10, "text/plain");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n" + "'", str2, "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.spaceprogram.util.CookieUtils.SECONDS_PER_WEEK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 604800 + "'", int0 == 604800);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String str2 = com.spaceprogram.util.FormUtils.createHourSelect((int) (short) 10, "hi!");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n" + "'", str2, "<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int[] intArray1 = com.spaceprogram.util.ArrayUtils.intStringToArray("");
        java.lang.Class<?> wildcardClass2 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[]");
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.ACCOUNT_INTERNAL_TAX_RECEIVABLE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 502 + "'", int0 == 502);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.BANK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.io.InputStream inputStream0 = null;
        com.spaceprogram.util.ByteArrayDataSource byteArrayDataSource2 = new com.spaceprogram.util.ByteArrayDataSource(inputStream0, "text/plain");
        // The following exception was thrown during execution in test generation
        try {
            java.io.InputStream inputStream3 = byteArrayDataSource2.getInputStream();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: no data");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.String str0 = org.infohazard.maverick.ctl.Throwaway2.SUCCESS;
        org.junit.Assert.assertEquals("'" + str0 + "' != '" + "success" + "'", str0, "success");
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.util.Mailer mailer7 = new com.spaceprogram.util.Mailer("<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "text/plain", "text/plain", "success", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n", "", "");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double3 = com.spaceprogram.util.ServletUtils.getDoubleParameter(httpServletRequest0, "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.html.forms.ProductSelect productSelect2 = new com.spaceprogram.accounting.html.forms.ProductSelect(session0, (java.lang.Integer) 502);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        com.spaceprogram.accounting.setup.Preferences preferences4 = com.spaceprogram.accounting.setup.Preferences.getDefault();
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.datastore.AccountingPersistenceManager.savePreferences(sQLFactory0, connection1, 1, (int) (short) 100, preferences4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(preferences4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.String str2 = com.spaceprogram.util.StringUtils.escapeHTML("success", false);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "success" + "'", str2, "success");
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = com.spaceprogram.util.ServletUtils.getIntParameter(httpServletRequest0, "text/plain", 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getTaxesForInvoices(session0, (java.lang.Integer) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list3 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getAccountTypes(sQLFactory0, connection1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.String str4 = com.spaceprogram.util.StringUtils.padString("success", (-1), '4', '4');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "success" + "'", str4, "success");
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String[] strArray2 = new java.lang.String[] { "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n", "" };
        java.lang.String str3 = com.spaceprogram.util.ArrayUtils.arrayToString(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n," + "'", str3, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.String str2 = com.spaceprogram.util.FormUtils.createHourSelect((int) '4', "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n" + "'", str2, "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.spaceprogram.accounting.model.Link link2 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        link2.setUrl("hi!");
        link2.setSelected(true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.ACCOUNTS_RECEIVABLE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.stripWhitespaceToSingleSpace("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ," + "'", str1, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,");
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer mailer6 = new com.spaceprogram.mail.Mailer("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,", "", "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "hi!", "hi!", "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.ACCOUNT_INTERNAL_OPENING_BALANCE_EQUITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 101 + "'", int0 == 101);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.String str2 = com.spaceprogram.util.FormUtils.createMinuteSelect(10, "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "<select id=\"\" name=\"\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n" + "'", str2, "<select id=\"\" name=\"\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.spaceprogram.accounting.model.Logout logout0 = new com.spaceprogram.accounting.model.Logout();
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.stripCR("<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> " + "'", str1, "<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.spaceprogram.util.ByteArrayDataSource byteArrayDataSource2 = new com.spaceprogram.util.ByteArrayDataSource("hi!", "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = com.spaceprogram.util.ServletUtils.getStringParameter(httpServletRequest0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.spaceprogram.util.Mailer.CTYPE_PLAIN_TEXT = "success";
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.spaceprogram.util.ArrayUtils arrayUtils0 = new com.spaceprogram.util.ArrayUtils();
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.lang.Integer int2 = invoicePage0.getCustomerKey();
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        javax.servlet.ServletRequest servletRequest1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean2 = com.spaceprogram.util.FormUtils.isDefined("<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ", servletRequest1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.String[] strArray0 = com.spaceprogram.util.DateUtils.hour_strings;
        com.spaceprogram.util.DateUtils.month_strings = strArray0;
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.datastore.AccountingPersistenceManager.addCustomer(sQLFactory0, connection1, 100, (int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.String str0 = com.spaceprogram.util.Mailer.CTYPE_HTML;
        org.junit.Assert.assertEquals("'" + str0 + "' != '" + "text/html" + "'", str0, "text/html");
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.spaceprogram.util.CookieUtils.SECONDS_PER_DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86400 + "'", int0 == 86400);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.toJavascriptString("<select id=\"\" name=\"\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n" + "'", str1, "<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n");
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.nullToString("<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> " + "'", str1, "<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double3 = com.spaceprogram.util.ServletUtils.getDoubleParameter(httpServletRequest0, "hi!", 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        javax.servlet.http.HttpServletResponse httpServletResponse0 = null;
        javax.servlet.http.HttpServletRequest httpServletRequest1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean8 = com.spaceprogram.util.ServletUtils.returnFile(httpServletResponse0, httpServletRequest1, "", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n", "<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n", false, false, "<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n");
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: Return File Not Found.");
        } catch (java.io.FileNotFoundException e) {
            // Expected exception.
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray1 = com.spaceprogram.util.ArrayUtils.intStringToArray("text/plain");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"text/plain\"");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.spaceprogram.util.Mailer.CTYPE_HTML = "<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n";
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        net.sf.hibernate.Session session0 = null;
        com.spaceprogram.accounting.basic.Charge charge2 = null;
        java.util.Date date3 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.basic.Charge charge4 = com.spaceprogram.accounting.AccountingHelper.dupeChargeNonRecurrence(session0, (java.lang.Integer) 1, charge2, date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.spaceprogram.accounting.AccountingHelper accountingHelper0 = new com.spaceprogram.accounting.AccountingHelper();
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.html.forms.AccountSelect accountSelect2 = new com.spaceprogram.accounting.html.forms.AccountSelect(session0, (java.lang.Integer) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        javax.servlet.http.HttpServletResponse httpServletResponse0 = null;
        javax.servlet.http.HttpServletRequest httpServletRequest1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = com.spaceprogram.util.ServletUtils.returnFile(httpServletResponse0, httpServletRequest1, "text/html", "text/plain", "success", false, false);
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: Return File Not Found.");
        } catch (java.io.FileNotFoundException e) {
            // Expected exception.
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.stripHtmlTags("text/plain");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "text/plain" + "'", str1, "text/plain");
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.spaceprogram.accounting.model.Link link2 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        java.lang.String str3 = link2.getUrl();
        link2.setTitle("text/plain");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "hi!" + "'", str3, "hi!");
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.datastore.AccountingPersistenceManager.addCustomer(sQLFactory0, connection1, (int) (byte) 1, (int) ' ', (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.html.forms.CustomerSelect customerSelect2 = new com.spaceprogram.accounting.html.forms.CustomerSelect(session0, (java.lang.Integer) 101);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.String str0 = com.spaceprogram.util.StringUtils.whitespace;
        org.junit.Assert.assertEquals("'" + str0 + "' != '" + " \t\n\r" + "'", str0, " \t\n\r");
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        net.sf.hibernate.Session session0 = null;
        com.spaceprogram.accounting.basic.Charge charge2 = null;
        java.util.Date date3 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.basic.Charge charge4 = com.spaceprogram.accounting.AccountingHelper.dupeChargeNonRecurrence(session0, (java.lang.Integer) 502, charge2, date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer.sendMail("", "<select id=\"\" name=\"\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "hi!", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "text/plain", "error");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        javax.servlet.http.HttpServletResponse httpServletResponse1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.util.FormUtils.displayAllParameters(httpServletRequest0, httpServletResponse1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.SQLescape("<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n" + "'", str1, "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        net.sf.hibernate.Session session0 = null;
        com.spaceprogram.accounting.basic.Account account3 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getAcountByInternalId(session0, (java.lang.Integer) 2, (int) (byte) 0);
        org.junit.Assert.assertNull(account3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.spaceprogram.accounting.basic.Tax tax0 = new com.spaceprogram.accounting.basic.Tax();
        tax0.setInvoiceKey((java.lang.Integer) 100);
        java.math.BigDecimal bigDecimal3 = tax0.getPercent();
        org.junit.Assert.assertNull(bigDecimal3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.spaceprogram.accounting.model.Link link2 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        java.lang.String str3 = link2.getUrl();
        link2.setTitle("<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "hi!" + "'", str3, "hi!");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.io.InputStream inputStream0 = null;
        com.spaceprogram.util.ByteArrayDataSource byteArrayDataSource2 = new com.spaceprogram.util.ByteArrayDataSource(inputStream0, "text/plain");
        java.io.OutputStream outputStream3 = byteArrayDataSource2.getOutputStream();
        org.junit.Assert.assertNotNull(outputStream3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str2 = com.spaceprogram.util.StringUtils.trim("hi!", 86400);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "hi!" + "'", str2, "hi!");
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.basic.Product product2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getProduct(session0, (java.lang.Integer) 604800);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.ACCOUNT_INTERNAL_ACCOUNTS_PAYABLE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1002 + "'", int0 == 1002);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.spaceprogram.Main main0 = new com.spaceprogram.Main();
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.spaceprogram.accounting.model.Vendor vendor0 = new com.spaceprogram.accounting.model.Vendor();
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.String str3 = com.spaceprogram.util.StringUtils.stringReplace("", "text/plain", "hi!");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.spaceprogram.util.CookieUtils cookieUtils0 = new com.spaceprogram.util.CookieUtils();
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.OTHER_ASSETS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.addUrlParam("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        pageElements1.setUrlParams("text/plain");
        com.spaceprogram.accounting.model.LinkGroup linkGroup7 = pageElements1.getSubNavLinkGroup();
        pageElements1.setUrlParams("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(linkGroup7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.String str3 = com.spaceprogram.util.StringUtils.padString("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", (int) (byte) 10, ' ');
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ," + "'", str3, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.lang.String str2 = pageElements1.getSectionTitle();
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        java.lang.String str4 = account0.getCurrency();
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.spaceprogram.accounting.datastore.AccountingPersistenceManager.tablePrefix = "hi!";
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.html.forms.CustomerSelect customerSelect2 = new com.spaceprogram.accounting.html.forms.CustomerSelect(session0, (java.lang.Integer) 502);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.stripCR("text/plain");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "text/plain" + "'", str1, "text/plain");
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getProducts(session0, (java.lang.Integer) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.spaceprogram.accounting.model.Link link2 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        link2.setUrl("hi!");
        link2.setUrl("hi!");
        link2.setTarget(" \t\n\r");
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        com.spaceprogram.accounting.basic.AClass aClass4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.datastore.AccountingPersistenceManager.saveAClass(sQLFactory0, connection1, (int) '#', 604800, aClass4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str1 = com.spaceprogram.util.ServletUtils.getAllParametersAsHTML(httpServletRequest0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.spaceprogram.accounting.model.InvoiceList invoiceList0 = new com.spaceprogram.accounting.model.InvoiceList();
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String str2 = com.spaceprogram.util.FormUtils.createHourSelect(502, " \t\n\r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n" + "'", str2, "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double3 = com.spaceprogram.util.ServletUtils.getDoubleParameter(httpServletRequest0, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,", (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.String str3 = com.spaceprogram.util.StringUtils.padString("", (int) (short) -1, '#');
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.spaceprogram.accounting.model.Link link2 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        link2.setUrl("hi!");
        link2.setOnClick("hi!");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.basic.Account account3 = com.spaceprogram.accounting.setup.DefaultAccountSetup.createInternalAccount(session0, (java.lang.Integer) 86400, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.spaceprogram.mail.Mailer.CTYPE_PLAIN_TEXT = "<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n";
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.spaceprogram.util.Mailer.CTYPE_PLAIN_TEXT = "hi!";
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.common.Recurrence recurrence3 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getRecurrence(session0, "<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ", "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer mailer6 = new com.spaceprogram.mail.Mailer("text/html", " \t\n\r", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,", "", "<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.stripWhitespace("<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>" + "'", str1, "<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>");
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        javax.servlet.http.HttpServletResponse httpServletResponse0 = null;
        javax.servlet.http.HttpServletRequest httpServletRequest1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = com.spaceprogram.util.ServletUtils.returnFile(httpServletResponse0, httpServletRequest1, "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n", "text/plain", true, false);
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: Return File Not Found.");
        } catch (java.io.FileNotFoundException e) {
            // Expected exception.
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String str1 = com.spaceprogram.util.FormUtils.createMinuteSelect((int) (short) 100);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n" + "'", str1, "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.spaceprogram.util.SecurityUtils securityUtils0 = new com.spaceprogram.util.SecurityUtils();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int[] intArray1 = com.spaceprogram.util.ArrayUtils.intStringToArray("");
        java.lang.String str2 = com.spaceprogram.util.ArrayUtils.arrayToString(intArray1);
        java.lang.String str3 = com.spaceprogram.util.ArrayUtils.arrayToString(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[]");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        com.spaceprogram.accounting.model.LinkGroup linkGroup2 = pageElements1.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage3 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements4 = invoicePage3.getPageElements();
        java.util.List list5 = pageElements4.getSubNavLinks();
        linkGroup2.setLinks(list5);
        linkGroup2.setSelectedByTitle("hi!");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(linkGroup2);
        org.junit.Assert.assertNotNull(pageElements4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.spaceprogram.util.Mailer.CTYPE_PLAIN_TEXT = "text/plain";
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.setup.Preferences preferences3 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getPreferences(sQLFactory0, connection1, (java.lang.Integer) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.String str1 = com.spaceprogram.util.FormUtils.createDaySelect((int) (short) -1);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n" + "'", str1, "<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n");
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.String str2 = com.spaceprogram.util.StringUtils.padInt((int) 'a', (int) (byte) 1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "97" + "'", str2, "97");
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Integer int2 = com.spaceprogram.accounting.AccountingHelper.getNextInvoiceNumber(session0, (java.lang.Integer) 1002);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int[] intArray1 = com.spaceprogram.util.ArrayUtils.intStringToArray("");
        java.lang.String str2 = com.spaceprogram.util.ArrayUtils.arrayToString(intArray1);
        com.spaceprogram.util.ArrayUtils.fillIntArray(intArray1, (int) '4');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[]");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        boolean boolean2 = pageElements1.showSearch();
        boolean boolean3 = pageElements1.hasErrors();
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.OTHER_EXPENSE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 82 + "'", int0 == 82);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.util.Mailer mailer6 = new com.spaceprogram.util.Mailer("", "hi!", "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        account0.setId((java.lang.Integer) (-1));
        java.math.BigDecimal bigDecimal6 = null;
        account0.setBalance(bigDecimal6);
        java.lang.Integer int8 = account0.getParentKey();
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNull(int8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.spaceprogram.accounting.html.reports.CustomerStatement customerStatement0 = new com.spaceprogram.accounting.html.reports.CustomerStatement();
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.spaceprogram.accounting.basic.Product product0 = com.spaceprogram.accounting.basic.Product.getDefault();
        product0.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal3 = product0.getRate();
        product0.setTaxable(false);
        product0.setDescription("");
        org.junit.Assert.assertNotNull(product0);
        org.junit.Assert.assertNotNull(bigDecimal3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getTaxes(session0, (java.lang.Integer) 101);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.String str2 = com.spaceprogram.util.StringUtils.padInt((int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "-1" + "'", str2, "-1");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.ACCOUNT_INTERNAL_TAX_PAYABLE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 501 + "'", int0 == 501);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.spaceprogram.accounting.common.Recurrence recurrence2 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence2.setZ(0);
        recurrence2.setCountdown((int) (byte) 1);
        org.junit.Assert.assertNotNull(recurrence2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getTaxesForInvoices(session0, (java.lang.Integer) 86400);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry0 = new com.spaceprogram.accounting.basic.JournalEntry();
        journalEntry0.setEntryNumber((java.lang.Integer) 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        account0.setName("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.ACCOUNT_INTERNAL_ACCOUNTS_RECEIVABLE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1001 + "'", int0 == 1001);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.spaceprogram.accounting.setup.Preferences preferences0 = com.spaceprogram.accounting.setup.Preferences.getDefault();
        preferences0.setId(9);
        org.junit.Assert.assertNotNull(preferences0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int[] intArray1 = com.spaceprogram.util.ArrayUtils.intStringToArray("");
        com.spaceprogram.util.ArrayUtils.fillIntArray(intArray1, 502);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[]");
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getAccounts(session0, (java.lang.Integer) 502);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer mailer6 = new com.spaceprogram.mail.Mailer("<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,", "<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        com.spaceprogram.accounting.basic.AClass aClass4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.datastore.AccountingPersistenceManager.saveAClass(sQLFactory0, connection1, (int) (short) 1, 1, aClass4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        com.spaceprogram.accounting.model.LinkGroup linkGroup3 = pageElements1.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.LinkGroup linkGroup4 = pageElements1.getNavLinkGroup();
        pageElements1.setSearchSection("");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(linkGroup3);
        org.junit.Assert.assertNotNull(linkGroup4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        javax.servlet.http.HttpServletResponse httpServletResponse0 = null;
        javax.servlet.http.HttpServletRequest httpServletRequest1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = com.spaceprogram.util.ServletUtils.returnFile(httpServletResponse0, httpServletRequest1, "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "hi!", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n", false, true);
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: Return File Not Found.");
        } catch (java.io.FileNotFoundException e) {
            // Expected exception.
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.spaceprogram.accounting.model.Link link3 = new com.spaceprogram.accounting.model.Link("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "text/plain", "text/html");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String str1 = com.spaceprogram.util.ServletUtils.headWithTitle("");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE></TITLE></HEAD>\n" + "'", str1, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE></TITLE></HEAD>\n");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry0 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date1 = journalEntry0.getEntryDate();
        java.lang.Integer int2 = journalEntry0.getId();
        journalEntry0.setMemo("text/html");
        java.lang.Integer int5 = journalEntry0.getCompanyKey();
        org.junit.Assert.assertNotNull(date1);
// flaky:         org.junit.Assert.assertEquals(date1.toString(), "Wed Jun 08 20:22:03 BRT 2022");
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNull(int5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        net.sf.hibernate.Session session0 = null;
        com.spaceprogram.accounting.basic.Invoice invoice1 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.removeChargesFromInvoice(session0, invoice1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        invoicePage0.setFormaction("text/html");
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.spaceprogram.util.Mailer.CTYPE_HTML = "hi!";
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.spaceprogram.accounting.basic.Tax tax0 = new com.spaceprogram.accounting.basic.Tax();
        tax0.setInvoiceKey((java.lang.Integer) 100);
        tax0.setInvoiceKey((java.lang.Integer) (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.spaceprogram.accounting.model.Link link2 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        link2.setUrl("hi!");
        link2.setUrl("hi!");
        link2.setTitle("hi!");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getTaxes(session0, (java.lang.Integer) 86400);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.VENDOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.spaceprogram.accounting.basic.Company company0 = new com.spaceprogram.accounting.basic.Company();
        company0.setActive(true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        javax.servlet.http.HttpServletResponse httpServletResponse0 = null;
        javax.servlet.http.HttpServletRequest httpServletRequest1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = com.spaceprogram.util.ServletUtils.returnFile(httpServletResponse0, httpServletRequest1, " \t\n\r", "", "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", true, false);
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: Return File Not Found.");
        } catch (java.io.FileNotFoundException e) {
            // Expected exception.
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double3 = com.spaceprogram.util.ServletUtils.getDoubleParameter(httpServletRequest0, "<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>", (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        invoicePage0.setFormaction("<select id=\"hi!\" name=\"hi!\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\" SELECTED>10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        com.spaceprogram.accounting.basic.Account account3 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getAccount(sQLFactory0, connection1, 86400);
        org.junit.Assert.assertNull(account3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.setMainPage("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        com.spaceprogram.accounting.model.InvoicePage invoicePage5 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements6 = invoicePage5.getPageElements();
        com.spaceprogram.accounting.model.LinkGroup linkGroup7 = pageElements6.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage8 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements9 = invoicePage8.getPageElements();
        java.util.List list10 = pageElements9.getSubNavLinks();
        pageElements9.addUrlParam("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        pageElements9.setUrlParams("text/plain");
        com.spaceprogram.accounting.model.LinkGroup linkGroup15 = pageElements9.getSubNavLinkGroup();
        pageElements6.setNavLinkGroup(linkGroup15);
        pageElements1.setSubNavLinkGroup(linkGroup15);
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(pageElements6);
        org.junit.Assert.assertNotNull(linkGroup7);
        org.junit.Assert.assertNotNull(pageElements9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(linkGroup15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigDecimal bigDecimal3 = com.spaceprogram.util.ServletUtils.getBigDecimalParameter(httpServletRequest0, "", "<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        byte[] byteArray0 = new byte[] {};
        com.spaceprogram.util.ByteArrayDataSource byteArrayDataSource2 = new com.spaceprogram.util.ByteArrayDataSource(byteArray0, " \t\n\r");
        java.lang.String str3 = byteArrayDataSource2.getContentType();
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + " \t\n\r" + "'", str3, " \t\n\r");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        net.sf.hibernate.Session session0 = null;
        com.spaceprogram.accounting.basic.Charge charge2 = null;
        com.spaceprogram.accounting.basic.JournalEntry journalEntry3 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date4 = journalEntry3.getEntryDate();
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.basic.Charge charge5 = com.spaceprogram.accounting.AccountingHelper.dupeChargeNonRecurrence(session0, (java.lang.Integer) 9, charge2, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(date4);
// flaky:         org.junit.Assert.assertEquals(date4.toString(), "Wed Jun 08 20:22:03 BRT 2022");
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.String str1 = com.spaceprogram.util.FormUtils.createHourSelect(604800);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"hour_select\" name=\"hour_select\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n" + "'", str1, "<select id=\"hour_select\" name=\"hour_select\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account0.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Account account5 = com.spaceprogram.accounting.basic.Account.getDefault();
        account5.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account5.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Product product10 = com.spaceprogram.accounting.basic.Product.getDefault();
        product10.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal13 = product10.getRate();
        account5.setBalance(bigDecimal13);
        account0.setBalance(bigDecimal13);
        java.math.BigDecimal bigDecimal16 = account0.balance;
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNotNull(account5);
        org.junit.Assert.assertNotNull(product10);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertNotNull(bigDecimal16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = com.spaceprogram.util.ServletUtils.getStringParameter(httpServletRequest0, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry0 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date1 = journalEntry0.getEntryDate();
        java.lang.Integer int2 = journalEntry0.getId();
        journalEntry0.setMemo("-1");
        org.junit.Assert.assertNotNull(date1);
// flaky:         org.junit.Assert.assertEquals(date1.toString(), "Wed Jun 08 20:22:04 BRT 2022");
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        boolean boolean1 = chargePage0.isDupe();
        java.lang.String str2 = chargePage0.getChargeRealm();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "6677" + "'", str2, "6677");
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.spaceprogram.accounting.basic.Tax tax0 = new com.spaceprogram.accounting.basic.Tax();
        tax0.setInvoiceKey((java.lang.Integer) 100);
        tax0.setName("text/html");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.LONG_TERM_LIABILITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.spaceprogram.accounting.basic.Product product0 = com.spaceprogram.accounting.basic.Product.getDefault();
        product0.setId((java.lang.Integer) 0);
        product0.setCode("success");
        java.lang.Integer int5 = product0.getCompanyKey();
        org.junit.Assert.assertNotNull(product0);
        org.junit.Assert.assertNull(int5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.spaceprogram.accounting.basic.Tax tax0 = new com.spaceprogram.accounting.basic.Tax();
        tax0.setInvoiceKey((java.lang.Integer) 100);
        tax0.setId((java.lang.Integer) 101);
        tax0.setCompanyKey((java.lang.Integer) 604800);
        java.math.BigDecimal bigDecimal7 = tax0.getPercent();
        org.junit.Assert.assertNull(bigDecimal7);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.addUrlParam("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        pageElements1.setUrlParams("text/plain");
        com.spaceprogram.accounting.model.LinkGroup linkGroup7 = pageElements1.getSubNavLinkGroup();
        pageElements1.setSectionTitle("success");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(linkGroup7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.spaceprogram.accounting.setup.Preferences preferences0 = com.spaceprogram.accounting.setup.Preferences.getDefault();
        java.lang.String str1 = preferences0.getFromEmail();
        org.junit.Assert.assertNotNull(preferences0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.io.InputStream inputStream0 = null;
        com.spaceprogram.util.ByteArrayDataSource byteArrayDataSource2 = new com.spaceprogram.util.ByteArrayDataSource(inputStream0, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n");
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.String str1 = com.spaceprogram.util.FormUtils.createMinuteSelect(0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n" + "'", str1, "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.spaceprogram.accounting.model.ChargeList chargeList0 = new com.spaceprogram.accounting.model.ChargeList();
        java.lang.String str1 = chargeList0.getSitename();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.addUrlParam("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        com.spaceprogram.accounting.model.InvoicePage invoicePage5 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements6 = invoicePage5.getPageElements();
        com.spaceprogram.accounting.model.LinkGroup linkGroup7 = pageElements6.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage8 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements9 = invoicePage8.getPageElements();
        java.util.List list10 = pageElements9.getSubNavLinks();
        linkGroup7.setLinks(list10);
        pageElements1.setNavLinkGroup(linkGroup7);
        com.spaceprogram.accounting.basic.JournalEntry journalEntry13 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Collection collection14 = journalEntry13.getTransactions();
        com.spaceprogram.accounting.model.InvoicePage invoicePage15 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements16 = invoicePage15.getPageElements();
        com.spaceprogram.accounting.model.LinkGroup linkGroup17 = pageElements16.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage18 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements19 = invoicePage18.getPageElements();
        java.util.List list20 = pageElements19.getSubNavLinks();
        java.lang.String str21 = pageElements19.getSectionColor();
        java.util.List list22 = pageElements19.getSubNavLinks();
        linkGroup17.setLinks(list22);
        journalEntry13.setTransactions((java.util.Collection) list22);
        pageElements1.setExtraNav(list22);
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(pageElements6);
        org.junit.Assert.assertNotNull(linkGroup7);
        org.junit.Assert.assertNotNull(pageElements9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(pageElements16);
        org.junit.Assert.assertNotNull(linkGroup17);
        org.junit.Assert.assertNotNull(pageElements19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.spaceprogram.mail.Mailer.CTYPE_PLAIN_TEXT = "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n";
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.spaceprogram.accounting.basic.Tax tax0 = com.spaceprogram.accounting.basic.Tax.getDefault();
        org.junit.Assert.assertNotNull(tax0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.COGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 71 + "'", int0 == 71);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        chargePage0.setClid((java.lang.Integer) 604800);
        boolean boolean3 = chargePage0.isShowChargeLines();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.stripDoubleQuotes("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<!DOCTYPE HTML PUBLIC  -//W3C//DTD HTML 4.0 Transitional//EN >\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n" + "'", str1, "<!DOCTYPE HTML PUBLIC  -//W3C//DTD HTML 4.0 Transitional//EN >\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n");
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.String str3 = com.spaceprogram.util.StringUtils.padString("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", 101, 'a');
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ," + "'", str3, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer.sendMail("error", "<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>", "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", "<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n", "97");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.spaceprogram.accounting.setup.Preferences preferences0 = com.spaceprogram.accounting.setup.Preferences.getDefault();
        int int1 = preferences0.getId();
        preferences0.setFromEmail("<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        org.junit.Assert.assertNotNull(preferences0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = com.spaceprogram.util.CookieUtils.SECONDS_PER_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2592000 + "'", int0 == 2592000);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account0.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Account account5 = com.spaceprogram.accounting.basic.Account.getDefault();
        account5.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account5.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Product product10 = com.spaceprogram.accounting.basic.Product.getDefault();
        product10.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal13 = product10.getRate();
        account5.setBalance(bigDecimal13);
        account0.setBalance(bigDecimal13);
        java.lang.String str16 = account0.getCurrency();
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNotNull(account5);
        org.junit.Assert.assertNotNull(product10);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "text/plain" + "'", str16, "text/plain");
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.spaceprogram.util.DateUtils dateUtils0 = new com.spaceprogram.util.DateUtils();
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.spaceprogram.accounting.basic.PaymentDistribution paymentDistribution0 = com.spaceprogram.accounting.basic.PaymentDistribution.getDefault();
        paymentDistribution0.setInvoiceKey((java.lang.Integer) 1);
        org.junit.Assert.assertNotNull(paymentDistribution0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        boolean boolean1 = chargePage0.isDupe();
        com.spaceprogram.accounting.model.PageElements pageElements2 = chargePage0.getPageElements();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(pageElements2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.spaceprogram.accounting.common.Recurrence recurrence2 = com.spaceprogram.accounting.common.Recurrence.getDefault("<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>", "97");
        org.junit.Assert.assertNotNull(recurrence2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.spaceprogram.mail.StringDataSource stringDataSource0 = new com.spaceprogram.mail.StringDataSource();
        java.io.InputStream inputStream1 = stringDataSource0.getInputStream();
        java.lang.String str2 = stringDataSource0.getContentType();
        org.junit.Assert.assertNull(inputStream1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.util.Mailer mailer7 = new com.spaceprogram.util.Mailer(" \t\n\r", "<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n", "97", "success", "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "text/plain", "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        java.math.BigDecimal bigDecimal4 = null;
        account0.setBalance(bigDecimal4);
        int int6 = account0.getInternalId();
        account0.setParentKey((java.lang.Integer) 101);
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.spaceprogram.accounting.basic.AClass aClass3 = new com.spaceprogram.accounting.basic.AClass(502, 9, "text/plain");
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = com.spaceprogram.util.ServletUtils.getStringParameter(httpServletRequest0, "success", "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer mailer7 = new com.spaceprogram.mail.Mailer("6677", "hi!", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,", "97", "97", "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", "<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.spaceprogram.accounting.util.Currency[] currencyArray0 = com.spaceprogram.accounting.util.Currency.currencies;
        org.junit.Assert.assertNotNull(currencyArray0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        int int4 = account0.getTypeKey();
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer.sendMail("<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n", "-1", "-1", "<select id=\"hour_select\" name=\"hour_select\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "&<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n", "-1", "<select id=\"hi!\" name=\"hi!\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.addUrlParam("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        com.spaceprogram.accounting.model.LinkGroup linkGroup5 = new com.spaceprogram.accounting.model.LinkGroup();
        pageElements1.setSubNavLinkGroup(linkGroup5);
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.spaceprogram.accounting.basic.AClass aClass0 = new com.spaceprogram.accounting.basic.AClass();
        int int1 = aClass0.getId();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.spaceprogram.accounting.model.PaymentPage paymentPage0 = new com.spaceprogram.accounting.model.PaymentPage();
        paymentPage0.setCustomerKey((java.lang.Integer) 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer mailer6 = new com.spaceprogram.mail.Mailer("&<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n", "", "<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n", "<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.spaceprogram.accounting.model.CompanySelect companySelect0 = new com.spaceprogram.accounting.model.CompanySelect();
        java.lang.String str1 = companySelect0.getRealm();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "accounting" + "'", str1, "accounting");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        com.spaceprogram.accounting.common.Recurrence recurrence8 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence8.setZ(0);
        java.util.Date date11 = recurrence8.getEndDate();
        int int12 = recurrence8.getX();
        com.spaceprogram.accounting.common.Recurrence recurrence15 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence15.setZ(0);
        com.spaceprogram.accounting.common.Recurrence recurrence20 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry21 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date22 = journalEntry21.getEntryDate();
        recurrence20.setEndDate(date22);
        java.util.Date date24 = recurrence15.getNextDate(date22);
        recurrence8.setEndDate(date22);
        com.spaceprogram.accounting.common.Recurrence recurrence29 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        java.lang.Long long30 = recurrence29.getId();
        recurrence29.setX((int) (short) -1);
        com.spaceprogram.accounting.common.Recurrence recurrence35 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence35.setZ(0);
        com.spaceprogram.accounting.common.Recurrence recurrence40 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry41 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date42 = journalEntry41.getEntryDate();
        recurrence40.setEndDate(date42);
        java.util.Date date44 = recurrence35.getNextDate(date42);
        recurrence29.setEndDate(date44);
        // The following exception was thrown during execution in test generation
        try {
            int int47 = com.spaceprogram.accounting.common.Queue.updateQueue(sQLFactory0, connection1, (int) '#', 1, 86400, "&<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n", date22, (int) (short) -1, date44, 2592000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(recurrence8);
        org.junit.Assert.assertNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(recurrence15);
        org.junit.Assert.assertNotNull(recurrence20);
        org.junit.Assert.assertNotNull(date22);
// flaky:         org.junit.Assert.assertEquals(date22.toString(), "Wed Jun 08 20:22:05 BRT 2022");
        org.junit.Assert.assertNotNull(date24);
// flaky:         org.junit.Assert.assertEquals(date24.toString(), "Thu Jun 30 20:22:05 BRT 2022");
        org.junit.Assert.assertNotNull(recurrence29);
        org.junit.Assert.assertNull(long30);
        org.junit.Assert.assertNotNull(recurrence35);
        org.junit.Assert.assertNotNull(recurrence40);
        org.junit.Assert.assertNotNull(date42);
// flaky:         org.junit.Assert.assertEquals(date42.toString(), "Wed Jun 08 20:22:05 BRT 2022");
        org.junit.Assert.assertNotNull(date44);
// flaky:         org.junit.Assert.assertEquals(date44.toString(), "Thu Jun 30 20:22:05 BRT 2022");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.String str0 = com.spaceprogram.util.StringUtils.DIGIT_BAG;
        org.junit.Assert.assertEquals("'" + str0 + "' != '" + "1234567890" + "'", str0, "1234567890");
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.spaceprogram.accounting.common.Recurrence recurrence2 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence2.setZ(0);
        java.util.Date date5 = recurrence2.getEndDate();
        int int6 = recurrence2.getX();
        com.spaceprogram.accounting.common.Recurrence recurrence9 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence9.setZ(0);
        com.spaceprogram.accounting.common.Recurrence recurrence14 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry15 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date16 = journalEntry15.getEntryDate();
        recurrence14.setEndDate(date16);
        java.util.Date date18 = recurrence9.getNextDate(date16);
        recurrence2.setEndDate(date16);
        java.lang.String str20 = recurrence2.getItemKey();
        org.junit.Assert.assertNotNull(recurrence2);
        org.junit.Assert.assertNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(recurrence9);
        org.junit.Assert.assertNotNull(recurrence14);
        org.junit.Assert.assertNotNull(date16);
// flaky:         org.junit.Assert.assertEquals(date16.toString(), "Wed Jun 08 20:22:05 BRT 2022");
        org.junit.Assert.assertNotNull(date18);
// flaky:         org.junit.Assert.assertEquals(date18.toString(), "Thu Jun 30 20:22:05 BRT 2022");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "error" + "'", str20, "error");
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        com.spaceprogram.accounting.model.LinkGroup linkGroup2 = pageElements1.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage3 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements4 = invoicePage3.getPageElements();
        java.util.List list5 = pageElements4.getSubNavLinks();
        java.lang.String str6 = pageElements4.getSectionColor();
        java.util.List list7 = pageElements4.getSubNavLinks();
        linkGroup2.setLinks(list7);
        java.util.List list9 = linkGroup2.getLinks();
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(linkGroup2);
        org.junit.Assert.assertNotNull(pageElements4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        account0.setId((java.lang.Integer) (-1));
        java.math.BigDecimal bigDecimal6 = account0.getBalance();
        int int7 = account0.getDetailTypeKey();
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNull(bigDecimal6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.spaceprogram.accounting.basic.Product product0 = com.spaceprogram.accounting.basic.Product.getDefault();
        product0.setId((java.lang.Integer) 0);
        product0.setName("hi!");
        org.junit.Assert.assertNotNull(product0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.String str2 = com.spaceprogram.util.StringUtils.stripCharsNotInBag("text/plain", "6677");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        chargePage0.setChargeNumber((java.lang.Integer) 502);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.NON_CURRENT_ASSETS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.INCOME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 61 + "'", int0 == 61);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        pageElements1.setShowSearch(false);
        java.util.List list4 = pageElements1.getSubNavLinks();
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        boolean boolean2 = pageElements1.showSearch();
        pageElements1.addUrlParam("<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n");
        java.lang.String str5 = pageElements1.getUrlParams();
        java.lang.String str6 = pageElements1.getUrlParams();
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "&<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n" + "'", str5, "&<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "&<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n" + "'", str6, "&<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n");
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.html.forms.AccountSelect accountSelect2 = new com.spaceprogram.accounting.html.forms.AccountSelect(session0, (java.lang.Integer) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.spaceprogram.accounting.common.Recurrence recurrence2 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence2.setZ(0);
        recurrence2.setX(502);
        java.lang.String str7 = recurrence2.getItemKey();
        java.lang.String str8 = recurrence2.getItemKey();
        org.junit.Assert.assertNotNull(recurrence2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "error" + "'", str7, "error");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "error" + "'", str8, "error");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.String str1 = com.spaceprogram.util.StringUtils.stripWhitespaceToSingleSpace("<select id=\"hour_select\" name=\"hour_select\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select id=\"hour_select\" name=\"hour_select\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\">10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> " + "'", str1, "<select id=\"hour_select\" name=\"hour_select\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\">10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.spaceprogram.accounting.model.RecurrencePage recurrencePage0 = new com.spaceprogram.accounting.model.RecurrencePage();
        java.lang.String str1 = recurrencePage0.getRealm();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.addError("<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.basic.Charge charge2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getCharge(session0, (java.lang.Integer) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.spaceprogram.accounting.basic.Invoice invoice0 = new com.spaceprogram.accounting.basic.Invoice();
        java.util.Collection collection1 = invoice0.getCharges();
        org.junit.Assert.assertNotNull(collection1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        com.spaceprogram.accounting.basic.Account account1 = com.spaceprogram.accounting.basic.Account.getDefault();
        account1.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account1.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Account account6 = com.spaceprogram.accounting.basic.Account.getDefault();
        account6.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account6.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Product product11 = com.spaceprogram.accounting.basic.Product.getDefault();
        product11.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal14 = product11.getRate();
        account6.setBalance(bigDecimal14);
        account1.setBalance(bigDecimal14);
        account0.balance = bigDecimal14;
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNotNull(account1);
        org.junit.Assert.assertNotNull(account6);
        org.junit.Assert.assertNotNull(product11);
        org.junit.Assert.assertNotNull(bigDecimal14);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account0.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Product product5 = com.spaceprogram.accounting.basic.Product.getDefault();
        product5.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal8 = product5.getRate();
        account0.setBalance(bigDecimal8);
        account0.setDescription("<selectid=\"hi!\"name=\"hi!\"><optionvalue=\"0\">12AM<optionvalue=\"1\">1AM<optionvalue=\"2\">2AM<optionvalue=\"3\">3AM<optionvalue=\"4\">4AM<optionvalue=\"5\">5AM<optionvalue=\"6\">6AM<optionvalue=\"7\">7AM<optionvalue=\"8\">8AM<optionvalue=\"9\">9AM<optionvalue=\"10\"SELECTED>10AM<optionvalue=\"11\">11AM<optionvalue=\"12\">12PM<optionvalue=\"13\">1PM<optionvalue=\"14\">2PM<optionvalue=\"15\">3PM<optionvalue=\"16\">4PM<optionvalue=\"17\">5PM<optionvalue=\"18\">6PM<optionvalue=\"19\">7PM<optionvalue=\"20\">8PM<optionvalue=\"21\">9PM<optionvalue=\"22\">10PM<optionvalue=\"23\">11PM</select>");
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNotNull(product5);
        org.junit.Assert.assertNotNull(bigDecimal8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.spaceprogram.accounting.basic.Invoice invoice0 = new com.spaceprogram.accounting.basic.Invoice();
        java.util.Date date1 = invoice0.getDueDate();
        java.util.Date date2 = invoice0.getInvoiceDate();
        java.lang.Integer int3 = invoice0.getCompanyKey();
        invoice0.setBillTo("1234567890");
        com.spaceprogram.accounting.basic.Charge charge6 = null;
        invoice0.addCharge(charge6);
        org.junit.Assert.assertNull(date1);
        org.junit.Assert.assertNull(date2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.spaceprogram.accounting.html.forms.CountrySelect countrySelect0 = new com.spaceprogram.accounting.html.forms.CountrySelect();
        boolean boolean1 = countrySelect0.isMultiple();
        java.util.List list2 = countrySelect0.getSelected();
        boolean boolean3 = countrySelect0.isMultiple();
        countrySelect0.setName("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.spaceprogram.accounting.basic.PaymentDistribution paymentDistribution0 = com.spaceprogram.accounting.basic.PaymentDistribution.getDefault();
        java.lang.Integer int1 = paymentDistribution0.getTransactionKey();
        org.junit.Assert.assertNotNull(paymentDistribution0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        pageElements1.setMainPage("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,");
        boolean boolean4 = pageElements1.hasErrors();
        pageElements1.setSearchSection("<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.spaceprogram.accounting.common.Recurrence recurrence0 = new com.spaceprogram.accounting.common.Recurrence();
        recurrence0.setZ((int) (short) 0);
        java.util.Date date3 = recurrence0.getNextDate();
        org.junit.Assert.assertNull(date3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.addUrlParam("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        pageElements1.setUrlParams("text/plain");
        com.spaceprogram.accounting.model.LinkGroup linkGroup7 = pageElements1.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage8 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements9 = invoicePage8.getPageElements();
        com.spaceprogram.accounting.model.LinkGroup linkGroup10 = pageElements9.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage11 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements12 = invoicePage11.getPageElements();
        java.util.List list13 = pageElements12.getSubNavLinks();
        java.lang.String str14 = pageElements12.getSectionColor();
        java.util.List list15 = pageElements12.getSubNavLinks();
        linkGroup10.setLinks(list15);
        com.spaceprogram.accounting.model.LinkGroup linkGroup17 = new com.spaceprogram.accounting.model.LinkGroup(list15);
        pageElements1.setExtraHead(list15);
        pageElements1.setShowSearch(true);
        pageElements1.addError("97");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(linkGroup7);
        org.junit.Assert.assertNotNull(pageElements9);
        org.junit.Assert.assertNotNull(linkGroup10);
        org.junit.Assert.assertNotNull(pageElements12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        boolean boolean1 = chargePage0.isDupe();
        boolean boolean2 = chargePage0.isShowChargeLines();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.util.WebappProperties webappProperties0 = com.spaceprogram.util.WebappProperties.getSingletonInstance();
            org.junit.Assert.fail("Expected exception of type java.lang.Exception; message: Could not find file: webapp.properties!");
        } catch (java.lang.Exception e) {
            // Expected exception.
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list3 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getChargesByCustomer(session0, (java.lang.Integer) 100, (java.lang.Integer) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.String str0 = com.spaceprogram.util.ServletUtils.DOCTYPE;
        org.junit.Assert.assertEquals("'" + str0 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">" + "'", str0, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">");
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.spaceprogram.accounting.model.Link link3 = new com.spaceprogram.accounting.model.Link("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "hi!", "<select id=\"\" name=\"\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
        java.lang.String str4 = link3.getTitle();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ," + "'", str4, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,");
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        java.util.List list2 = pageElements1.getSubNavLinks();
        pageElements1.setMainPage("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        pageElements1.addError("text/html");
        java.lang.String str7 = pageElements1.getSectionTitle();
        com.spaceprogram.accounting.model.Link link10 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        link10.setUrl("hi!");
        link10.setOnClick("<select id=\"\" name=\"\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        java.lang.String str15 = link10.createLink();
        pageElements1.addNavLink(link10);
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "<a href=\"hi!\">hi!</a>" + "'", str15, "<a href=\"hi!\">hi!</a>");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.spaceprogram.accounting.basic.AccountingCustomer accountingCustomer0 = new com.spaceprogram.accounting.basic.AccountingCustomer();
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        com.spaceprogram.accounting.model.LinkGroup linkGroup2 = pageElements1.getSubNavLinkGroup();
        com.spaceprogram.accounting.model.InvoicePage invoicePage3 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements4 = invoicePage3.getPageElements();
        java.util.List list5 = pageElements4.getSubNavLinks();
        pageElements4.addUrlParam("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n,");
        pageElements4.setUrlParams("text/plain");
        com.spaceprogram.accounting.model.LinkGroup linkGroup10 = pageElements4.getSubNavLinkGroup();
        pageElements1.setNavLinkGroup(linkGroup10);
        com.spaceprogram.accounting.model.Link link14 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        link14.setUrl("hi!");
        boolean boolean17 = link14.isSelected();
        java.lang.String str18 = link14.getTitle();
        java.lang.String str19 = link14.createLink();
        linkGroup10.addLink(link14);
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertNotNull(linkGroup2);
        org.junit.Assert.assertNotNull(pageElements4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(linkGroup10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "hi!" + "'", str18, "hi!");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "<a href=\"hi!\">hi!</a>" + "'", str19, "<a href=\"hi!\">hi!</a>");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.String str2 = com.spaceprogram.util.FormUtils.createMinuteSelect((int) (short) 10, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "<select id=\"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,\" name=\"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n" + "'", str2, "<select id=\"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,\" name=\"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        java.lang.Integer int1 = chargePage0.getClid();
        java.lang.Integer int2 = chargePage0.getProductKey();
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.spaceprogram.accounting.model.PageElements pageElements0 = new com.spaceprogram.accounting.model.PageElements();
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account0.setCurrency("text/plain");
        account0.setInternalId((int) ' ');
        int int7 = account0.getTypeKey();
        java.lang.String str8 = account0.getName();
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.String[] strArray0 = com.spaceprogram.util.DateUtils.getMonthStrings();
        java.lang.String str1 = com.spaceprogram.util.ArrayUtils.arrayToString(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "12 AM,1 AM,2 AM,3 AM,4 AM,5 AM,6 AM,7 AM,8 AM,9 AM,10 AM,11 AM,12 PM,1 PM,2 PM,3 PM,4 PM,5 PM,6 PM,7 PM,8 PM,9 PM,10 PM,11 PM" + "'", str1, "12 AM,1 AM,2 AM,3 AM,4 AM,5 AM,6 AM,7 AM,8 AM,9 AM,10 AM,11 AM,12 PM,1 PM,2 PM,3 PM,4 PM,5 PM,6 PM,7 PM,8 PM,9 PM,10 PM,11 PM");
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.setup.Preferences preferences3 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getPreferences(sQLFactory0, connection1, (java.lang.Integer) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.spaceprogram.accounting.basic.Invoice invoice0 = new com.spaceprogram.accounting.basic.Invoice();
        java.util.Date date1 = invoice0.getDueDate();
        java.util.Date date2 = invoice0.getInvoiceDate();
        java.lang.Integer int3 = invoice0.getCompanyKey();
        java.math.BigDecimal bigDecimal4 = invoice0.getTotal();
        org.junit.Assert.assertNull(date1);
        org.junit.Assert.assertNull(date2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(bigDecimal4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.mail.Mailer mailer6 = new com.spaceprogram.mail.Mailer("97", "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", "text/html", "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", "", "text/html");
            org.junit.Assert.fail("Expected exception of type javax.mail.internet.AddressException; message: Extra route-addr");
        } catch (javax.mail.internet.AddressException e) {
            // Expected exception.
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getTaxesForInvoices(session0, (java.lang.Integer) 501);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        java.lang.String str1 = chargePage0.getChargeRealm();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "6677" + "'", str1, "6677");
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.spaceprogram.accounting.setup.Preferences preferences0 = com.spaceprogram.accounting.setup.Preferences.getDefault();
        int int1 = preferences0.getId();
        preferences0.setId(1002);
        int int4 = preferences0.getCompanyKey();
        preferences0.setCompanyKey(0);
        org.junit.Assert.assertNotNull(preferences0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        boolean boolean2 = invoicePage0.hasErrors();
        invoicePage0.setFormaction("");
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getProducts(session0, (java.lang.Integer) 501);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        java.math.BigDecimal bigDecimal4 = null;
        account0.setBalance(bigDecimal4);
        com.spaceprogram.accounting.basic.Account account6 = com.spaceprogram.accounting.basic.Account.getDefault();
        account6.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account6.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Product product11 = com.spaceprogram.accounting.basic.Product.getDefault();
        product11.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal14 = product11.getRate();
        account6.setBalance(bigDecimal14);
        account0.balance = bigDecimal14;
        java.lang.String str17 = account0.name;
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(account6);
        org.junit.Assert.assertNotNull(product11);
        org.junit.Assert.assertNotNull(bigDecimal14);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        java.lang.Integer int1 = chargePage0.getClid();
        boolean boolean2 = chargePage0.isRec();
        java.lang.String str3 = chargePage0.getChargeRealm();
        boolean boolean4 = chargePage0.isShowChargeLines();
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "6677" + "'", str3, "6677");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        javax.servlet.http.HttpServletRequest httpServletRequest0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigDecimal bigDecimal3 = com.spaceprogram.util.ServletUtils.getBigDecimalParameter(httpServletRequest0, "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", "<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.spaceprogram.accounting.basic.Product product0 = com.spaceprogram.accounting.basic.Product.getDefault();
        product0.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal3 = product0.getRate();
        product0.setTaxable(false);
        java.lang.String str6 = product0.getCode();
        org.junit.Assert.assertNotNull(product0);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.spaceprogram.accounting.model.Overview overview0 = new com.spaceprogram.accounting.model.Overview();
        overview0.addError("97", "<select id=\"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,\" name=\"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,\" >\n<option value=\"0\">00\n<option value=\"5\">05\n<option value=\"10\" selected>10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n");
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.spaceprogram.accounting.util.Currency currency2 = new com.spaceprogram.accounting.util.Currency("success", "<select id=\"hour_select\" name=\"hour_select\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        currency2.setCode("<select id='' name='' \\n<option value='0'>0\\n<option value='5'>0\\n<option value='10' selected>1\\n<option value='15'>1\\n<option value='20'>2\\n<option value='25'>2\\n<option value='30'>3\\n<option value='35'>3\\n<option value='40'>4\\n<option value='45'>4\\n<option value='50'>5\\n<option value='55'>5\\n</select\\n");
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.spaceprogram.accounting.basic.Invoice invoice0 = new com.spaceprogram.accounting.basic.Invoice();
        com.spaceprogram.accounting.basic.JournalEntry journalEntry1 = new com.spaceprogram.accounting.basic.JournalEntry();
        com.spaceprogram.accounting.common.Recurrence recurrence4 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence4.setZ(0);
        java.util.Date date7 = recurrence4.getEndDate();
        int int8 = recurrence4.getX();
        com.spaceprogram.accounting.common.Recurrence recurrence11 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence11.setZ(0);
        com.spaceprogram.accounting.common.Recurrence recurrence16 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry17 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date18 = journalEntry17.getEntryDate();
        recurrence16.setEndDate(date18);
        java.util.Date date20 = recurrence11.getNextDate(date18);
        recurrence4.setEndDate(date18);
        journalEntry1.setEntryDate(date18);
        com.spaceprogram.accounting.common.Recurrence recurrence25 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence25.setZ(0);
        com.spaceprogram.accounting.common.Recurrence recurrence30 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry31 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date32 = journalEntry31.getEntryDate();
        recurrence30.setEndDate(date32);
        java.util.Date date34 = recurrence25.getNextDate(date32);
        journalEntry1.setEntryDate(date32);
        invoice0.setInvoiceDate(date32);
        java.lang.String str37 = invoice0.getBillTo();
        org.junit.Assert.assertNotNull(recurrence4);
        org.junit.Assert.assertNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(recurrence11);
        org.junit.Assert.assertNotNull(recurrence16);
        org.junit.Assert.assertNotNull(date18);
// flaky:         org.junit.Assert.assertEquals(date18.toString(), "Wed Jun 08 20:22:07 BRT 2022");
        org.junit.Assert.assertNotNull(date20);
// flaky:         org.junit.Assert.assertEquals(date20.toString(), "Thu Jun 30 20:22:07 BRT 2022");
        org.junit.Assert.assertNotNull(recurrence25);
        org.junit.Assert.assertNotNull(recurrence30);
        org.junit.Assert.assertNotNull(date32);
// flaky:         org.junit.Assert.assertEquals(date32.toString(), "Wed Jun 08 20:22:07 BRT 2022");
        org.junit.Assert.assertNotNull(date34);
// flaky:         org.junit.Assert.assertEquals(date34.toString(), "Thu Jun 30 20:22:07 BRT 2022");
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.spaceprogram.accounting.basic.Invoice invoice0 = new com.spaceprogram.accounting.basic.Invoice();
        java.util.Date date1 = invoice0.getDueDate();
        boolean boolean2 = invoice0.isToBePrinted();
        int int3 = invoice0.getTemplateKey();
        org.junit.Assert.assertNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = com.spaceprogram.accounting.basic.AccountTypes.CREDIT_CARD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.spaceprogram.accounting.basic.AClass aClass3 = new com.spaceprogram.accounting.basic.AClass(502, (-1), " \t\n\r");
        aClass3.setCompanyKey(61);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        java.lang.Integer int1 = chargePage0.getClid();
        chargePage0.setRec(true);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.crossdb.sql.SQLFactory sQLFactory0 = null;
        java.sql.Connection connection1 = null;
        com.spaceprogram.accounting.basic.Account account3 = com.spaceprogram.accounting.basic.Account.getDefault();
        account3.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account3.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Product product8 = com.spaceprogram.accounting.basic.Product.getDefault();
        product8.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal11 = product8.getRate();
        account3.setBalance(bigDecimal11);
        com.spaceprogram.accounting.datastore.AccountingPersistenceManager.saveAccount(sQLFactory0, connection1, (int) (byte) 0, account3);
        account3.setInternalId(502);
        org.junit.Assert.assertNotNull(account3);
        org.junit.Assert.assertNotNull(product8);
        org.junit.Assert.assertNotNull(bigDecimal11);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.spaceprogram.accounting.html.forms.CountrySelect countrySelect0 = new com.spaceprogram.accounting.html.forms.CountrySelect();
        boolean boolean1 = countrySelect0.isMultiple();
        java.util.List list2 = countrySelect0.getSelected();
        boolean boolean3 = countrySelect0.isMultiple();
        countrySelect0.setName("<select id=\"text/plain\" name=\"text/plain\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\" SELECTED>10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.spaceprogram.util.WebappProperties webappProperties0 = new com.spaceprogram.util.WebappProperties();
        java.lang.String str2 = webappProperties0.getProperty("<select id=\"hour_select\" name=\"hour_select\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\">10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
        com.spaceprogram.accounting.common.Recurrence recurrence5 = com.spaceprogram.accounting.common.Recurrence.getDefault("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,", "error");
        recurrence5.setZ(0);
        recurrence5.setX(502);
        recurrence5.setRealm("<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n");
        java.lang.Object obj12 = webappProperties0.get((java.lang.Object) "<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n");
        com.spaceprogram.accounting.model.Link link15 = new com.spaceprogram.accounting.model.Link("hi!", "hi!");
        link15.setUrl("hi!");
        boolean boolean18 = link15.isSelected();
        com.spaceprogram.mail.StringDataSource stringDataSource19 = new com.spaceprogram.mail.StringDataSource();
        com.spaceprogram.accounting.html.forms.CountrySelect countrySelect20 = new com.spaceprogram.accounting.html.forms.CountrySelect();
        java.util.List list21 = countrySelect20.getSelected();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean22 = webappProperties0.replace((java.lang.Object) boolean18, (java.lang.Object) stringDataSource19, (java.lang.Object) list21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(recurrence5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(list21);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.String str1 = com.spaceprogram.util.FormUtils.createColorSelect("text/html");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "<select name=\"color_select\" id=\"color_select\">\n<option value=\"Black\" style=\"color:Black\">Black\n<option value=\"Maroon\" style=\"color:Maroon\">Maroon\n<option value=\"Green\" style=\"color:Green\">Green\n<option value=\"Olive\" style=\"color:Olive\">Olive\n<option value=\"Navy\" style=\"color:Navy\">Navy\n<option value=\"Purple\" style=\"color:Purple\">Purple\n<option value=\"Teal\" style=\"color:Teal\">Teal\n<option value=\"Gray\" style=\"color:Gray\">Gray\n<option value=\"Silver\" style=\"color:Silver\">Silver\n<option value=\"Red\" style=\"color:Red\">Red\n<option value=\"Lime\" style=\"color:Lime\">Lime\n<option value=\"Yellow\" style=\"color:Yellow\">Yellow\n<option value=\"Blue\" style=\"color:Blue\">Blue\n<option value=\"Fuschia\" style=\"color:Fuschia\">Fuschia\n<option value=\"Aqua\" style=\"color:Aqua\">Aqua\n<option value=\"White\" style=\"color:White\">White\n</select>\n" + "'", str1, "<select name=\"color_select\" id=\"color_select\">\n<option value=\"Black\" style=\"color:Black\">Black\n<option value=\"Maroon\" style=\"color:Maroon\">Maroon\n<option value=\"Green\" style=\"color:Green\">Green\n<option value=\"Olive\" style=\"color:Olive\">Olive\n<option value=\"Navy\" style=\"color:Navy\">Navy\n<option value=\"Purple\" style=\"color:Purple\">Purple\n<option value=\"Teal\" style=\"color:Teal\">Teal\n<option value=\"Gray\" style=\"color:Gray\">Gray\n<option value=\"Silver\" style=\"color:Silver\">Silver\n<option value=\"Red\" style=\"color:Red\">Red\n<option value=\"Lime\" style=\"color:Lime\">Lime\n<option value=\"Yellow\" style=\"color:Yellow\">Yellow\n<option value=\"Blue\" style=\"color:Blue\">Blue\n<option value=\"Fuschia\" style=\"color:Fuschia\">Fuschia\n<option value=\"Aqua\" style=\"color:Aqua\">Aqua\n<option value=\"White\" style=\"color:White\">White\n</select>\n");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.spaceprogram.accounting.model.ChargePage chargePage0 = new com.spaceprogram.accounting.model.ChargePage();
        java.lang.Integer int1 = chargePage0.getClid();
        boolean boolean2 = chargePage0.isRec();
        java.lang.String str3 = chargePage0.getChargeRealm();
        boolean boolean4 = chargePage0.isRec();
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "6677" + "'", str3, "6677");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.spaceprogram.accounting.basic.Invoice invoice0 = new com.spaceprogram.accounting.basic.Invoice();
        java.util.Date date1 = invoice0.getDueDate();
        java.util.Date date2 = invoice0.getInvoiceDate();
        java.lang.Integer int3 = invoice0.getCompanyKey();
        invoice0.setBillTo("1234567890");
        invoice0.setInvoiceNumber((java.lang.Integer) 1002);
        invoice0.setCustomerKey((java.lang.Integer) (-1));
        org.junit.Assert.assertNull(date1);
        org.junit.Assert.assertNull(date2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.spaceprogram.util.WebappProperties webappProperties0 = new com.spaceprogram.util.WebappProperties();
        java.util.Set<java.util.Map.Entry<java.lang.Object, java.lang.Object>> objEntrySet1 = webappProperties0.entrySet();
        org.junit.Assert.assertNotNull(objEntrySet1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.spaceprogram.accounting.model.Link link2 = new com.spaceprogram.accounting.model.Link("<select id=\"minute_select\" name=\"minute_select\" >\n<option value=\"0\" selected>00\n<option value=\"5\">05\n<option value=\"10\">10\n<option value=\"15\">15\n<option value=\"20\">20\n<option value=\"25\">25\n<option value=\"30\">30\n<option value=\"35\">35\n<option value=\"40\">40\n<option value=\"45\">45\n<option value=\"50\">50\n<option value=\"55\">55\n</select>\n", " \t\n\r");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.spaceprogram.util.Mailer.CTYPE_HTML = "<select id=\" \t\n\r\" name=\" \t\n\r\" >\n<option value=\"0\">12 AM\n<option value=\"1\">1 AM\n<option value=\"2\">2 AM\n<option value=\"3\">3 AM\n<option value=\"4\">4 AM\n<option value=\"5\">5 AM\n<option value=\"6\">6 AM\n<option value=\"7\">7 AM\n<option value=\"8\">8 AM\n<option value=\"9\">9 AM\n<option value=\"10\">10 AM\n<option value=\"11\">11 AM\n<option value=\"12\">12 PM\n<option value=\"13\">1 PM\n<option value=\"14\">2 PM\n<option value=\"15\">3 PM\n<option value=\"16\">4 PM\n<option value=\"17\">5 PM\n<option value=\"18\">6 PM\n<option value=\"19\">7 PM\n<option value=\"20\">8 PM\n<option value=\"21\">9 PM\n<option value=\"22\">10 PM\n<option value=\"23\">11 PM\n</select>\n";
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.spaceprogram.accounting.basic.AClass aClass3 = new com.spaceprogram.accounting.basic.AClass(502, (-1), " \t\n\r");
        java.lang.String str4 = aClass3.getName();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + " \t\n\r" + "'", str4, " \t\n\r");
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        com.spaceprogram.accounting.model.PageElements pageElements1 = invoicePage0.getPageElements();
        boolean boolean2 = pageElements1.showSearch();
        pageElements1.addUrlParam("<select id=\"day_select\" name=\"day_select\">\n<option value=\"1\">1\n<option value=\"2\">2\n<option value=\"3\">3\n<option value=\"4\">4\n<option value=\"5\">5\n<option value=\"6\">6\n<option value=\"7\">7\n<option value=\"8\">8\n<option value=\"9\">9\n<option value=\"10\">10\n<option value=\"11\">11\n<option value=\"12\">12\n<option value=\"13\">13\n<option value=\"14\">14\n<option value=\"15\">15\n<option value=\"16\">16\n<option value=\"17\">17\n<option value=\"18\">18\n<option value=\"19\">19\n<option value=\"20\">20\n<option value=\"21\">21\n<option value=\"22\">22\n<option value=\"23\">23\n<option value=\"24\">24\n<option value=\"25\">25\n<option value=\"26\">26\n<option value=\"27\">27\n<option value=\"28\">28\n<option value=\"29\">29\n<option value=\"30\">30\n<option value=\"31\">31\n</select>\n");
        java.util.List list5 = pageElements1.getSubNavLinks();
        org.junit.Assert.assertNotNull(pageElements1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.spaceprogram.accounting.datastore.AccountingPersistenceManager.APP_ID_CHARGE = 22;
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.spaceprogram.accounting.setup.Preferences preferences0 = com.spaceprogram.accounting.setup.Preferences.getDefault();
        int int1 = preferences0.getId();
        preferences0.setId(1002);
        int int4 = preferences0.getCompanyKey();
        java.lang.String str5 = preferences0.getFromEmail();
        org.junit.Assert.assertNotNull(preferences0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        net.sf.hibernate.Session session0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.spaceprogram.accounting.basic.Charge charge2 = com.spaceprogram.accounting.datastore.AccountingPersistenceManager.getCharge(session0, (java.lang.Integer) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        java.lang.Integer int1 = invoicePage0.getId();
        invoicePage0.setCustomerKey((java.lang.Integer) 10);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        java.lang.Integer int1 = invoicePage0.getId();
        int int2 = invoicePage0.getAccessLevel();
        invoicePage0.setInvoiceNumber((java.lang.Integer) 82);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        java.math.BigDecimal bigDecimal4 = null;
        account0.setBalance(bigDecimal4);
        com.spaceprogram.accounting.basic.Account account6 = com.spaceprogram.accounting.basic.Account.getDefault();
        account6.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        account6.setCurrency("text/plain");
        com.spaceprogram.accounting.basic.Product product11 = com.spaceprogram.accounting.basic.Product.getDefault();
        product11.setId((java.lang.Integer) 0);
        java.math.BigDecimal bigDecimal14 = product11.getRate();
        account6.setBalance(bigDecimal14);
        account0.balance = bigDecimal14;
        java.lang.Integer int17 = account0.getId();
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(account6);
        org.junit.Assert.assertNotNull(product11);
        org.junit.Assert.assertNotNull(bigDecimal14);
        org.junit.Assert.assertNull(int17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.spaceprogram.accounting.basic.JournalEntry journalEntry0 = new com.spaceprogram.accounting.basic.JournalEntry();
        java.util.Date date1 = journalEntry0.getEntryDate();
        java.lang.Integer int2 = journalEntry0.getId();
        journalEntry0.setMemo("text/html");
        java.lang.String str5 = journalEntry0.getMemo();
        java.lang.String str6 = journalEntry0.getMemo();
        com.spaceprogram.accounting.basic.Transaction transaction7 = null;
        journalEntry0.addTransaction(transaction7);
        org.junit.Assert.assertNotNull(date1);
// flaky:         org.junit.Assert.assertEquals(date1.toString(), "Wed Jun 08 20:22:07 BRT 2022");
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "text/html" + "'", str5, "text/html");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "text/html" + "'", str6, "text/html");
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        com.spaceprogram.util.ByteArrayDataSource byteArrayDataSource3 = new com.spaceprogram.util.ByteArrayDataSource(byteArray1, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"> <HTML> <HEAD><TITLE>hi!</TITLE></HEAD> ,");
        com.spaceprogram.mail.ByteArrayDataSource byteArrayDataSource5 = new com.spaceprogram.mail.ByteArrayDataSource(byteArray1, "hi!");
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[0]");
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.spaceprogram.accounting.basic.Account account0 = com.spaceprogram.accounting.basic.Account.getDefault();
        account0.description = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n";
        java.lang.Integer int3 = account0.getCompanyKey();
        java.lang.String str4 = account0.description;
        org.junit.Assert.assertNotNull(account0);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n" + "'", str4, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n<HTML>\n<HEAD><TITLE>hi!</TITLE></HEAD>\n");
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.spaceprogram.accounting.basic.ChargeLine chargeLine0 = new com.spaceprogram.accounting.basic.ChargeLine();
        com.spaceprogram.accounting.basic.Product product1 = com.spaceprogram.accounting.basic.Product.getDefault();
        java.lang.Integer int2 = product1.getId();
        java.math.BigDecimal bigDecimal3 = product1.getRate();
        chargeLine0.setQuantity(bigDecimal3);
        org.junit.Assert.assertNotNull(product1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(bigDecimal3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.spaceprogram.accounting.model.InvoicePage invoicePage0 = new com.spaceprogram.accounting.model.InvoicePage();
        java.lang.Integer int1 = invoicePage0.getId();
        int int2 = invoicePage0.getAccessLevel();
        invoicePage0.setCustomerKey((java.lang.Integer) 2592000);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.spaceprogram.util.WebappProperties webappProperties0 = new com.spaceprogram.util.WebappProperties();
        java.lang.String str2 = webappProperties0.getProperty("<select id=\"hour_select\" name=\"hour_select\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\">10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
        com.spaceprogram.util.WebappProperties webappProperties3 = new com.spaceprogram.util.WebappProperties();
        java.lang.String str5 = webappProperties3.getProperty("<select id=\"hour_select\" name=\"hour_select\" > <option value=\"0\">12 AM <option value=\"1\">1 AM <option value=\"2\">2 AM <option value=\"3\">3 AM <option value=\"4\">4 AM <option value=\"5\">5 AM <option value=\"6\">6 AM <option value=\"7\">7 AM <option value=\"8\">8 AM <option value=\"9\">9 AM <option value=\"10\">10 AM <option value=\"11\">11 AM <option value=\"12\">12 PM <option value=\"13\">1 PM <option value=\"14\">2 PM <option value=\"15\">3 PM <option value=\"16\">4 PM <option value=\"17\">5 PM <option value=\"18\">6 PM <option value=\"19\">7 PM <option value=\"20\">8 PM <option value=\"21\">9 PM <option value=\"22\">10 PM <option value=\"23\">11 PM </select> ");
        webappProperties0.putAll((java.util.Map<java.lang.Object, java.lang.Object>) webappProperties3);
        boolean boolean7 = webappProperties0.isEmpty();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.spaceprogram.accounting.model.Feedback feedback0 = new com.spaceprogram.accounting.model.Feedback();
        feedback0.setSubmitted(false);
    }
}
